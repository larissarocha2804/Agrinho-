/**
 * PROJETO AGRINHO 3D - VERSÃO OTIMIZADA
 * Casas realistas, prédios e cercado com animais
 */

let playerX = 0, playerZ = 0;
let playerAngle = 0;
let temPlanta = false;
let plantas = [];
let arvores = [];
let casas = [];
let predios = [];
let animais = [];
let cercas = [];
let estoque = 0;
let entregas = 0;
let gameState = "START";

// Câmera
let camAngle = 0;
let camDist = 550;
let isDragging = false;
let lastMouseX = 0;

function setup() {
  createCanvas(windowWidth, windowHeight, WEBGL);
  
  // Flores (menos quantidade)
  for (let x = -300; x < 150; x += 100) {
    for (let z = -250; z < 250; z += 100) {
      if (dist(x, z, 0, 0) < 300) {
        plantas.push({x: x, z: z});
      }
    }
  }
  
  // Árvores (menos quantidade)
  for (let i = 0; i < 25; i++) {
    let angle = random(TWO_PI);
    let r = random(400, 500);
    arvores.push({x: cos(angle) * r, z: sin(angle) * r});
  }
  
  // ========== CASAS (4 bairros) ==========
  // Norte
  for (let x = -400; x <= 400; x += 100) {
    for (let z = -900; z <= -650; z += 100) {
      casas.push({x: x, z: z, cor: [240, 220, 180], telhado: [180, 120, 80]});
    }
  }
  // Sul
  for (let x = -450; x <= 450; x += 100) {
    for (let z = 650; z <= 900; z += 100) {
      casas.push({x: x, z: z, cor: [220, 190, 150], telhado: [170, 110, 70]});
    }
  }
  // Leste
  for (let x = 650; x <= 900; x += 100) {
    for (let z = -400; z <= 400; z += 100) {
      casas.push({x: x, z: z, cor: [210, 180, 140], telhado: [160, 100, 60]});
    }
  }
  // Oeste
  for (let x = -900; x <= -650; x += 100) {
    for (let z = -400; z <= 400; z += 100) {
      casas.push({x: x, z: z, cor: [190, 210, 160], telhado: [150, 90, 50]});
    }
  }
  
  // ========== PRÉDIOS (menos quantidade) ==========
  for (let i = 0; i < 12; i++) {
    let angle = random(TWO_PI);
    let r = random(550, 620);
    predios.push({
      x: cos(angle) * r,
      z: sin(angle) * r,
      andares: floor(random(3, 6))
    });
  }
  
  // ========== CERCADO NO CANTO ESQUERDO (x: -400 a -150, z: -400 a -150) ==========
  for (let x = -400; x <= -150; x += 35) {
    cercas.push({x: x, z: -400, tipo: "cerca"});
    cercas.push({x: x, z: -150, tipo: "cerca"});
  }
  for (let z = -400; z <= -150; z += 35) {
    cercas.push({x: -400, z: z, tipo: "cerca"});
    cercas.push({x: -150, z: z, tipo: "cerca"});
  }
  // Portão
  cercas.push({x: -250, z: -150, tipo: "portao"});
  cercas.push({x: -215, z: -150, tipo: "portao"});
  
  // ========== ANIMAIS ==========
  for (let i = 0; i < 2; i++) animais.push({tipo: "vaca", x: random(-370, -180), z: random(-370, -180), angle: random(TWO_PI)});
  for (let i = 0; i < 3; i++) animais.push({tipo: "galinha", x: random(-370, -180), z: random(-370, -180), angle: random(TWO_PI)});
  for (let i = 0; i < 1; i++) animais.push({tipo: "porco", x: random(-370, -180), z: random(-370, -180), angle: random(TWO_PI)});
  animais.push({tipo: "cavalo", x: -280, z: -280, angle: random(TWO_PI)});
}

function draw() {
  background(100, 150, 250);
  
  if (gameState === "START") {
    telaInicio();
  } else if (gameState === "PLAY") {
    jogo();
  } else if (gameState === "WIN") {
    telaVitoria();
  }
}

function telaInicio() {
  camera(0, -200, 600, 0, 0, 0, 0, 1, 0);
  
  push();
  fill(34, 139, 34);
  translate(0, 30, 0);
  box(1600, 10, 1600);
  pop();
  
  push();
  translate(0, -150, 0);
  fill(0, 0, 0, 200);
  rect(-380, -100, 760, 200, 15);
  fill(255, 215, 0);
  textAlign(CENTER);
  textSize(28);
  text("🌾 AGRINHO 3D", 0, -50);
  textSize(18);
  fill(255);
  text("O Agro Conecta Tudo", 0, -10);
  textSize(14);
  text("🏘️ Casas e Prédios | 🐄 Cercado com Animais", 0, 25);
  text("🖱️ Mouse: Olhar | WASD: Mover", 0, 50);
  text("🔍 Roda: Zoom | ESPAÇO: Coletar/Entregar", 0, 70);
  textSize(20);
  fill(255, 215, 0);
  text("▶ PRESSIONE ESPAÇO", 0, 110);
  pop();
}

function jogo() {
  // Controle da câmera
  if (mouseIsPressed && mouseButton === LEFT) {
    if (isDragging) {
      camAngle += (mouseX - lastMouseX) * 0.01;
    }
    lastMouseX = mouseX;
    isDragging = true;
  } else {
    isDragging = false;
  }
  
  // Posição da câmera
  let camX = playerX + sin(camAngle) * camDist;
  let camZ = playerZ + cos(camAngle) * camDist;
  camera(camX, -180, camZ, playerX, -50, playerZ, 0, 1, 0);
  
  // Iluminação
  ambientLight(100);
  directionalLight(255, 255, 255, 0.5, -1, 0.5);
  
  // Chão
  push();
  fill(34, 139, 34);
  translate(0, 25, 0);
  box(1300, 10, 1300);
  pop();
  
  // Estradas
  push();
  fill(80);
  for (let z = -1000; z <= 1000; z += 50) {
    push();
    translate(0, 28, z);
    box(60, 5, 30);
    pop();
  }
  for (let x = -1000; x <= 1000; x += 50) {
    push();
    translate(x, 28, 0);
    box(30, 5, 60);
    pop();
  }
  pop();
  
  // Fábrica
  push();
  translate(0, -50, -180);
  fill(120, 100, 80);
  box(160, 100, 140);
  fill(150, 50, 50);
  translate(0, -60, 0);
  box(180, 25, 160);
  fill(100);
  translate(-50, -40, -40);
  cylinder(12, 50);
  pop();
  
  // Árvores
  for (let arv of arvores) {
    push();
    translate(arv.x, 20, arv.z);
    fill(101, 67, 33);
    cylinder(10, 45);
    fill(20, 100, 20);
    translate(0, -28, 0);
    sphere(22);
    pop();
  }
  
  // Flores
  for (let flor of plantas) {
    push();
    translate(flor.x, 25, flor.z);
    fill(0, 120, 0);
    cylinder(3, 18);
    translate(0, -10, 0);
    fill(255, random(100, 200), random(100, 200));
    for(let i = 0; i < 5; i++) {
      push();
      rotateY(i * 72);
      translate(7, 0, 0);
      sphere(4);
      pop();
    }
    fill(255, 255, 0);
    sphere(3);
    pop();
  }
  
  // Casas
  for (let casa of casas) {
    push();
    translate(casa.x, -25, casa.z);
    fill(casa.cor);
    box(45, 50, 45);
    fill(casa.telhado);
    translate(0, -30, 0);
    cone(35, 25);
    fill(101, 67, 33);
    translate(0, 5, 23);
    box(15, 25, 3);
    fill(135, 206, 235);
    translate(-15, -5, 0);
    box(12, 15, 2);
    translate(30, 0, 0);
    box(12, 15, 2);
    pop();
  }
  
  // Prédios
  for (let predio of predios) {
    let altura = predio.andares * 45;
    push();
    translate(predio.x, -altura/2 + 20, predio.z);
    fill(150, 150, 180);
    box(45, altura, 45);
    fill(255, 255, 200, 200);
    for (let i = 0; i < predio.andares; i++) {
      let y = -altura/2 + i * 45 + 22;
      push();
      translate(0, y, 23);
      box(15, 22, 2);
      pop();
    }
    fill(100);
    translate(0, -altura/2 - 8, 0);
    box(55, 12, 55);
    pop();
  }
  
  // Cercado
  push();
  stroke(139, 69, 19);
  strokeWeight(3);
  for (let cerca of cercas) {
    push();
    translate(cerca.x, 18, cerca.z);
    if (cerca.tipo === "portao") {
      fill(101, 67, 33);
      box(7, 35, 3);
      translate(18, 0, 0);
      box(7, 35, 3);
    } else {
      fill(139, 69, 19);
      box(5, 32, 5);
      translate(0, -8, 0);
      box(30, 3, 4);
      translate(0, 16, 0);
      box(30, 3, 4);
    }
    pop();
  }
  noStroke();
  pop();
  
  // Animais
  for (let animal of animais) {
    push();
    translate(animal.x, 12, animal.z);
    rotateY(animal.angle);
    
    if (animal.tipo === "vaca") {
      fill(255);
      box(22, 18, 35);
      fill(60);
      push(); translate(-6, -2, 10); box(8, 8, 6); pop();
      push(); translate(6, -2, 10); box(8, 8, 6); pop();
      fill(255);
      translate(0, 4, 22);
      box(16, 16, 18);
      fill(0);
      push(); translate(-5, -2, 10); sphere(2); pop();
      push(); translate(5, -2, 10); sphere(2); pop();
    } else if (animal.tipo === "galinha") {
      fill(255, 200, 100);
      scale(0.7);
      ellipse(0, 0, 20, 15);
      translate(0, -8, 10);
      sphere(8);
      fill(255, 100, 0);
      translate(0, 0, 6);
      cone(3, 6);
      fill(255, 0, 0);
      translate(0, -6, 0);
      sphere(3);
    } else if (animal.tipo === "porco") {
      fill(255, 180, 180);
      box(22, 16, 30);
      translate(0, 4, 18);
      sphere(11);
      fill(255, 150, 150);
      translate(0, 0, 7);
      sphere(6);
      fill(80, 50, 30);
      push(); translate(-3, -1, 5); sphere(1.5); pop();
      push(); translate(3, -1, 5); sphere(1.5); pop();
    } else if (animal.tipo === "cavalo") {
      fill(139, 69, 19);
      box(24, 20, 40);
      translate(0, 4, 26);
      box(14, 18, 20);
      fill(80, 50, 30);
      translate(0, -10, -4);
      box(12, 8, 16);
      fill(0);
      push(); translate(-5, -2, 10); sphere(2); pop();
      push(); translate(5, -2, 10); sphere(2); pop();
    }
    pop();
    animal.angle += 0.01;
  }
  
  // Jogador
  push();
  translate(playerX, -40, playerZ);
  rotateY(playerAngle);
  
  // Corpo
  fill(80, 60, 40);
  push(); translate(-7, 50, 0); box(10, 28, 10); pop();
  push(); translate(7, 50, 0); box(10, 28, 10); pop();
  fill(200, 100, 50);
  push(); translate(0, 28, 0); box(26, 38, 18); pop();
  push(); translate(-16, 28, 0); box(10, 28, 10); pop();
  push(); translate(16, 28, 0); box(10, 28, 10); pop();
  
  // Cabeça
  fill(255, 220, 180);
  sphere(15);
  fill(255);
  push(); translate(-5, -4, 14); sphere(3); pop();
  push(); translate(5, -4, 14); sphere(3); pop();
  fill(0);
  push(); translate(-5, -4, 16); sphere(1.5); pop();
  push(); translate(5, -4, 16); sphere(1.5); pop();
  noFill();
  stroke(80, 50, 30);
  arc(0, 3, 10, 5, 0, PI);
  noStroke();
  
  // Chapéu
  push();
  translate(0, -15, 0);
  fill(194, 165, 105);
  cylinder(28, 4);
  fill(184, 155, 95);
  translate(0, -6, 0);
  cylinder(20, 12);
  pop();
  
  // Flor na mão
  if (temPlanta) {
    push();
    translate(22, 22, 5);
    fill(0, 120, 0);
    cylinder(3, 18);
    translate(0, -10, 0);
    fill(255, 80, 180);
    for(let i = 0; i < 5; i++) {
      push();
      rotateY(i * 72);
      translate(7, 0, 0);
      sphere(4);
      pop();
    }
    fill(255, 255, 0);
    sphere(3);
    pop();
  }
  pop();
  
  // Movimento
  let speed = 6;
  if (keyIsDown(87) || keyIsDown(UP_ARROW)) playerZ -= speed;
  if (keyIsDown(83) || keyIsDown(DOWN_ARROW)) playerZ += speed;
  if (keyIsDown(65) || keyIsDown(LEFT_ARROW)) playerX -= speed;
  if (keyIsDown(68) || keyIsDown(RIGHT_ARROW)) playerX += speed;
  
  playerX = constrain(playerX, -850, 850);
  playerZ = constrain(playerZ, -850, 850);
  
  // HUD
  push();
  translate(0, -350, 0);
  fill(0, 0, 0, 180);
  rect(-300, -50, 600, 90, 10);
  fill(255, 215, 0);
  textSize(18);
  text("🌾 AGRO CONECTA TUDO", 0, -20);
  textSize(14);
  fill(255);
  text(`📦 ${estoque}  |  🚚 ${entregas}/10  |  🏠 ${casas.length}  |  🐄 ${animais.length}`, 0, 15);
  textSize(11);
  fill(200);
  text("ESPAÇO → Coletar/Entregar", 0, 40);
  pop();
  
  if (entregas >= 10) gameState = "WIN";
}

function telaVitoria() {
  camera(0, -200, 600, 0, 0, 0, 0, 1, 0);
  
  push();
  fill(34, 139, 34);
  translate(0, 30, 0);
  box(1600, 10, 1600);
  pop();
  
  push();
  translate(0, -100, 0);
  fill(0, 0, 0, 200);
  rect(-350, -80, 700, 160, 15);
  fill(255, 215, 0);
  textAlign(CENTER);
  textSize(28);
  text("✨ MISSÃO CUMPRIDA! ✨", 0, -30);
  textSize(20);
  text("🌍 Campo e Cidade em Harmonia", 0, 15);
  textSize(16);
  text("🐄🐓🐷 Todos os animais estão felizes!", 0, 50);
  text("ESPAÇO para jogar novamente", 0, 80);
  pop();
}

function keyPressed() {
  if (key === ' ') {
    if (gameState === "START") {
      gameState = "PLAY";
    } else if (gameState === "PLAY") {
      if (!temPlanta) {
        for (let i = 0; i < plantas.length; i++) {
          if (dist(playerX, playerZ, plantas[i].x, plantas[i].z) < 60) {
            temPlanta = true;
            plantas.splice(i, 1);
            break;
          }
        }
      } else {
        if (dist(playerX, playerZ, 0, -180) < 120) {
          temPlanta = false;
          estoque++;
          if (estoque >= 3) {
            entregas += floor(estoque / 3);
            estoque = estoque % 3;
          }
        }
      }
    } else if (gameState === "WIN") {
      resetJogo();
    }
  }
}

function mouseWheel(event) {
  camDist += event.delta * 0.5;
  camDist = constrain(camDist, 350, 900);
  return false;
}

function resetJogo() {
  playerX = 0;
  playerZ = 0;
  estoque = 0;
  entregas = 0;
  temPlanta = false;
  camAngle = 0;
  camDist = 550;
  
  plantas = [];
  for (let x = -300; x < 150; x += 100) {
    for (let z = -250; z < 250; z += 100) {
      if (dist(x, z, 0, 0) < 300) {
        plantas.push({x: x, z: z});
      }
    }
  }
  
  gameState = "START";
}